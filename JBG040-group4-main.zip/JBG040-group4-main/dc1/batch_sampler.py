import numpy as np
import random
import torch
import cv2
from dc1.image_dataset import ImageDataset
from typing import Generator, Tuple, Union

class BatchSampler:
    """
    Implements an iterable which given a torch dataset and a batch_size
    will produce batches of data of that given size. The batches are
    returned as tuples in the form (images, labels).
    Can produce balanced batches, where each batch will have an equal
    amount of samples from each class in the dataset. If your dataset is heavily

    imbalanced, this might mean throwing away a lot of samples from
    over-represented classes!
    """
    def __init__(self, batch_size: int, dataset: ImageDataset, balanced: bool = True, largest_aug_factor: int = 1, use_augmentation:bool = False) -> None:
        self.batch_size = batch_size
        self.dataset = dataset
        self.balanced = balanced
        self.largest_aug_factor = largest_aug_factor
        self.use_augmentation = use_augmentation

        if self.balanced:
            # Counting the ocurrence of the class labels:
            unique, counts = np.unique(self.dataset.targets, return_counts=True)
            max_count = int(max(counts))
            # Gets desired sample count per class
            target_count = max_count * self.largest_aug_factor 
            indexes = []
            for cls in unique:
                cls_indices = np.where(self.dataset.targets == cls)[0]
                n_cls = len(cls_indices)
                if n_cls > target_count:
                    chosen = np.random.choice(cls_indices, size=target_count, replace=False)
                    indexes.extend(chosen)
                else:
                    indexes.extend(cls_indices)
                    extra_needed = target_count - n_cls
                     # Sampling an equal amount from each class:
                    for _ in range(extra_needed):
                        chosen = np.random.choice(cls_indices)
                        indexes.append((chosen, True))
             # Setting the indexes we will sample from later:
            self.indexes = indexes
        else:
            # Setting the indexes we will sample from later (all indexes):
            self.indexes = list(range(len(self.dataset)))

    def __len__(self) -> int:
        return (len(self.indexes) // self.batch_size) + (1 if len(self.indexes) % self.batch_size != 0 else 0)

    def shuffle(self) -> None:
        random.shuffle(self.indexes)

    def __iter__(self) -> Generator[Tuple[torch.Tensor, torch.Tensor], None, None]:
        self.shuffle()
        batch = []
        for idx in self.indexes:
            if isinstance(idx, tuple):
                orig_idx, _ = idx
                # Get the original sample from the dataset.
                sample = self.dataset[orig_idx]
                if self.use_augmentation:
                    orig_img = sample[0].squeeze(0).numpy()
                    aug_img = self.dataset.augment_image(orig_img)
                    aug_tensor = torch.from_numpy(aug_img.astype(np.float32) / 255).unsqueeze(0)
                    sample = (aug_tensor, sample[1])
            else:
                sample = self.dataset[idx]
            batch.append(sample)
            if len(batch) == self.batch_size:
                X_batch = torch.stack([s[0] for s in batch]).float()
                Y_batch = torch.tensor([s[1] for s in batch]).long()
                yield X_batch, Y_batch
                batch = []
        if batch:
            # Return the last batch (smaller than batch_size):
            X_batch = torch.stack([s[0] for s in batch]).float()
            Y_batch = torch.tensor([s[1] for s in batch]).long()
            yield X_batch, Y_batch
