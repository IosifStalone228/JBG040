import numpy as np
import torch
import cv2
from pathlib import Path
from typing import Tuple, Optional

class ImageDataset:
    def __init__(
        self,
        x: Path,
        y: Path,
        augment: bool = True,
        n_augments: int = 1,
        test: bool = True,
        cache_path: Optional[Path] = None,
        force_recache: bool = False
    ) -> None:
        self.x = x
        self.y = y
        self.augment = augment
        self.n_augments = n_augments
        self.test = test
        self.cache_path = cache_path
        self.force_recache = force_recache

        # If we have a cache path and do not force recache, try to load cached data
        if self.cache_path and not self.force_recache and self._cache_exists():
            print("Loading processed data from cache...")
            self.processed_imgs, self.processed_targets = self._load_cache()
        else:
            # Otherwise, load from original .npy files and process
            print("Processing data from scratch...")
            self.imgs_orig = np.load(x)
            self.targets_orig = np.load(y)
            self._process_data()
            # If we have a cache path, save processed data
            if self.cache_path:
                self._save_cache(self.processed_imgs, self.processed_targets)

        # For compatibility with BatchSampler
        self.targets = self.processed_targets

    def _cache_exists(self) -> bool:
        """
        Returns True if the cache files exist.
        We'll save them as two npy files: <cache_path>.imgs.npy and <cache_path>.targets.npy
        """
        imgs_file = self.cache_path.with_suffix(".imgs.npy")
        targets_file = self.cache_path.with_suffix(".targets.npy")
        return imgs_file.is_file() and targets_file.is_file()

    def _load_cache(self):
        """
        Load cached processed_imgs and processed_targets.
        """
        imgs_file = self.cache_path.with_suffix(".imgs.npy")
        targets_file = self.cache_path.with_suffix(".targets.npy")
        processed_imgs = np.load(imgs_file)
        processed_targets = np.load(targets_file)
        return processed_imgs, processed_targets

    def _save_cache(self, imgs: np.ndarray, targets: np.ndarray):
        """
        Save processed arrays to disk for future runs.
        """
        imgs_file = self.cache_path.with_suffix(".imgs.npy")
        targets_file = self.cache_path.with_suffix(".targets.npy")
        np.save(imgs_file, imgs)
        np.save(targets_file, targets)
        print(f"Processed data cached to:\n  {imgs_file}\n  {targets_file}")
    def _process_data(self):
        imgs, targets = [], []
        for i in range(len(self.imgs_orig)):
            # Remove the singleton channel dimension
            img = np.squeeze(self.imgs_orig[i], axis=0)
            if not self.test:
                if np.mean(img == 0) > 0.5:
                    continue
            proc = self.resize_to_original(self.crop_nonzero(img), (128, 128))

            if not self.test and self.augment and self.n_augments > 1:
                for _ in range(self.n_augments):
                    imgs.append(self.augment_image(proc))
                    targets.append(self.targets_orig[i])
            else:
                imgs.append(proc)
                targets.append(self.targets_orig[i])
            self.processed_imgs = np.array(imgs)
            self.processed_targets = np.array(targets)

    def __len__(self) -> int:
        return len(self.processed_targets)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, np.ndarray]:
        img = self.processed_imgs[idx]
        # Convert image to a torch tensor, normalize to [0, 1], add a channel dimension
        tensor = torch.from_numpy(img.astype(np.float32) / 255).unsqueeze(0)
        return tensor, self.processed_targets[idx]

    @staticmethod
    def crop_nonzero(image: np.ndarray) -> np.ndarray:
        if np.all(image == 0):
            return image
        mask = image > 0
        coords = np.argwhere(mask)
        y_min, x_min = coords.min(axis=0)
        # Add 1 to include the last pixel
        y_max, x_max = coords.max(axis=0) + 1 
        return image[y_min:y_max, x_min:x_max]

    @staticmethod
    def resize_to_original(image: np.ndarray, size: Tuple[int, int]) -> np.ndarray:
        return cv2.resize(image, size, interpolation=cv2.INTER_AREA)

    @staticmethod
    def augment_image(image: np.ndarray) -> np.ndarray:
        # Rotate picture
        angle = np.random.uniform(-180, 180) 
        center = (image.shape[1] / 2, image.shape[0] / 2)
        M = cv2.getRotationMatrix2D(center, angle, 1.0)
        # Cut picture to original 128x128 orientation
        rotated = cv2.warpAffine(image, M, (image.shape[1], image.shape[0]),
                                  flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
        # Brightness adjustment
        factor = np.random.uniform(0.8, 1.2)
        aug = rotated.astype(np.float32) * factor
        return np.clip(aug, 0, 255).astype(image.dtype)
