import torch
import torch.nn as nn
import torchxrayvision as xrv


class CXRModel(nn.Module):
    def __init__(self, n_classes=6):
        super(CXRModel, self).__init__()

        # Load the pretrained Google CXR model
        self.base_model = xrv.models.DenseNet(weights="densenet121-res224-all")  # Loads a DenseNet121 trained on X-rays

        # Freeze pretrained layers (optional - for feature extraction)
        for param in self.base_model.parameters():
            param.requires_grad = False
        for param in list(self.base_model.parameters())[-30:]:  # Unfreeze last couple layers
            param.requires_grad = True

        # Replace the classifier layer with a new one for our 6 classes
        self.fc = nn.Sequential(
            nn.Linear(1024, 512),  # First hidden layer
            nn.BatchNorm1d(512),
            nn.ReLU(),
            nn.Dropout(0.3),  # Prevent overfitting
            nn.Linear(512, 256),  # Second hidden layer
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(256, 128),  # Third hidden layer
            nn.ReLU(),
            nn.Linear(128, n_classes)  # Final output layer
        )
        # self.fc = nn.Linear(1024, n_classes)  # Original model outputs 1024 features, adapt it for our 6-class task

    def forward(self, x):
        x = self.base_model.features(x)  # Extract features
        x = x.mean([2, 3])  # Global average pooling
        x = self.fc(x)  # Pass through new classifier
        return x