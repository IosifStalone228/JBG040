# train_test.py
from datetime import datetime

import pandas as pd
from tqdm import tqdm
import torch
import numpy as np
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
from dc1.net import Net
from dc1.batch_sampler import BatchSampler
from typing import Callable, List


def train_model(
        model: torch.nn.Module,
        train_sampler: BatchSampler,
        optimizer: torch.optim.Optimizer,
        loss_function: Callable[..., torch.Tensor],
        device: str,
) -> List[torch.Tensor]:
    # Keep track of all the losses:
    losses = []
    model.train()

    for batch in tqdm(train_sampler):
        x, y = batch
        x, y = x.to(device), y.to(device)
        predictions = model(x)
        loss = loss_function(predictions, y)
        losses.append(loss)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

    return losses


def test_model(
        model: torch.nn.Module,
        test_sampler: BatchSampler,
        loss_function: Callable[..., torch.Tensor],
        device: str,
) -> List[torch.Tensor]:
    model.eval()
    losses = []

    # We'll gather all predictions and labels for computing metrics at the end
    all_preds = []
    all_labels = []

    with torch.no_grad():
        for (x, y) in tqdm(test_sampler):
            x, y = x.to(device), y.to(device)

            prediction = model(x)
            loss = loss_function(prediction, y)
            losses.append(loss)

            # Convert logits to predicted class indices
            preds = torch.argmax(prediction, dim=1)
            # Store them to compute metrics later
            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(y.cpu().numpy())

    # Convert to numpy arrays
    all_preds = np.array(all_preds)
    all_labels = np.array(all_labels)

    # Compute metrics
    accuracy_val = accuracy_score(all_labels, all_preds)
    precision_val = precision_score(all_labels, all_preds, average="macro")
    recall_val = recall_score(all_labels, all_preds, average="macro")
    f1_val = f1_score(all_labels, all_preds, average="macro")

    # conf_matrix = confusion_matrix(all_labels, all_preds)

    # Print them
    print("\n=== Test Model Metrics ===")
    print(f"Accuracy:  {accuracy_val:.4f}")
    print(f"Precision: {precision_val:.4f} (macro-average)")
    print(f"Recall:    {recall_val:.4f} (macro-average)")
    print(f"F1 Score:  {f1_val:.4f} (macro-average)\n")
    # class_labels = [f"Class {i}" for i in range(conf_matrix.shape[0])]
    # df_conf_matrix = pd.DataFrame(conf_matrix, index=class_labels, columns=class_labels)
    now = datetime.now()
    # np.save(f"artifacts/confusion_matrix{now.microsecond}.npy", conf_matrix)
    # print("Confusion Matrix:")
    # print(df_conf_matrix)
    return losses